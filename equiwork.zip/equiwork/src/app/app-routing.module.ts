import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component'; // Import the Home component
import { EmployeeAttritionComponent } from './employee-attrition/employee-attrition.component';
import { GenderPayGapComponent } from './gender-pay-gap/gender-pay-gap.component';

const routes: Routes = [
  { path: '', redirectTo:'/home', pathMatch:'full'},
  { path:'home',component: HomeComponent },// Use HomeComponent for the default route
  { path: 'equiwork', component: EmployeeAttritionComponent },
  { path: 'genderpaygap', component: GenderPayGapComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
