import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeAttritionComponent } from './employee-attrition/employee-attrition.component'; // Update import
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule
import { EmployeeAttritionService } from './employee-attrition/employee-attrition.service';
import { HomeComponent } from './home/home.component';
import { GenderPayGapComponent } from './gender-pay-gap/gender-pay-gap.component'; // Import your service
import { GenderPayGapService } from './gender-pay-gap/gender-pay-gap.service';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeAttritionComponent,
    HomeComponent,
    GenderPayGapComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule, // Ensure HttpClientModule is included here
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [EmployeeAttritionService,GenderPayGapService],
  bootstrap: [AppComponent]
})
export class AppModule { }
