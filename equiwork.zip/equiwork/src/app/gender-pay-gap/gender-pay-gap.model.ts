// gender-pay-gap.model.ts
export class GenderPayGap {
  jobtitle: string;
  gender: string;
  age: number;
  perfeval: number;
  education: string;
  dept: string;
  seniority: number;
  bonus: number;

  constructor(
    jobtitle: string,
    gender: string,
    age: number,
    perfeval: number,
    education: string,
    dept: string,
    seniority: number,
    bonus: number,

  ) {
    this.jobtitle = jobtitle;
    this.gender = gender;
    this.age = age;
    this.perfeval = perfeval;
    this.education = education;
    this.dept = dept;
    this.seniority = seniority;
    this.bonus = bonus;
  }
}
