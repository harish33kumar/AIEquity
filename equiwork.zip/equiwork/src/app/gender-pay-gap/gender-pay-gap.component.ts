import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GenderPayGapService } from './gender-pay-gap.service';
import { GenderPayGap } from './gender-pay-gap.model';

@Component({
  selector: 'app-gender-pay-gap',
  templateUrl: './gender-pay-gap.component.html',
  styleUrls: ['./gender-pay-gap.component.css']
})
export class GenderPayGapComponent {
  employeeForm: FormGroup;
  responseMessage: any;

  constructor(private fb: FormBuilder, private genderPayGapService: GenderPayGapService) {
    this.employeeForm = this.fb.group({
      jobtitle: ['', Validators.required],
      gender: ['', Validators.required],
      age: ['', Validators.required],
      perfeval: ['', [Validators.required, Validators.pattern('^[0-9]+$')]], // Numeric validation
      education: ['', Validators.required],
      dept: ['', Validators.required],
      seniority: ['', Validators.required],
      bonus: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.employeeForm.valid) {
      const formValues = this.employeeForm.value;
      const employeeData = new GenderPayGap(
        formValues.jobtitle,
        formValues.gender,
        formValues.age,
        formValues.perfeval,
        formValues.education,
        formValues.dept,
        formValues.seniority,
        formValues.bonus
      );

      this.genderPayGapService.submitEmployeeData(employeeData).subscribe(
        response => { this.responseMessage = response; },
        error => { this.responseMessage = 'An error occurred while submitting the form.'; }
      );
    } else {
      console.log('Form is invalid. Please correct the errors and try again.');
    }
  }
}
