import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeAttritionService } from './employee-attrition.service';

@Component({
  selector: 'app-employee-attrition',
  templateUrl: './employee-attrition.component.html',
  styleUrls: ['./employee-attrition.component.css']
})
export class EmployeeAttritionComponent implements OnInit {
  inputForm!: FormGroup;
  responseMessage: any;
  fieldGroups:any;
  fields: string[] = [
    'Age', 'DailyRate', 'Department',
    'DistanceFromHome', 'Education', 'EducationField',
    'EmployeeNumber', 'EnvironmentSatisfaction', 'Gender', 'HourlyRate',
    'JobInvolvement', 'JobLevel', 'JobRole', 'JobSatisfaction',
    'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked',
    'PercentSalaryHike', 'PerformanceRating',
    'RelationshipSatisfaction', 'StockOptionLevel',
    'TotalWorkingYears', 'TrainingTimesLastYear', 'WorkLifeBalance',
    'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion',
    'YearsWithCurrManager'
  ];

  exampleValues: { [key: string]: string } = {
    Age: '41', DailyRate: '1102',
    Department: 'Sales', DistanceFromHome: '1', Education: '2',
    EducationField: 'Life Sciences', EmployeeNumber: '1',
    EnvironmentSatisfaction: '2', Gender: 'Female', HourlyRate: '94',
    JobInvolvement: '3', JobLevel: '2', JobRole: 'Sales Executive',
    JobSatisfaction: '4',MonthlyIncome: '5993',
    MonthlyRate: '19479', NumCompaniesWorked: '8',
    PercentSalaryHike: '11', PerformanceRating: '3',
    RelationshipSatisfaction: '1',
    StockOptionLevel: '0', TotalWorkingYears: '8', TrainingTimesLastYear: '0',
    WorkLifeBalance: '1', YearsAtCompany: '6', YearsInCurrentRole: '4',
    YearsSinceLastPromotion: '0', YearsWithCurrManager: '5'
  };

  numericFields: string[] = [
    'Age', 'DailyRate', 'DistanceFromHome', 'Education',
    'EmployeeNumber', 'EnvironmentSatisfaction', 'HourlyRate', 'JobInvolvement',
    'JobLevel', 'JobSatisfaction', 'MonthlyIncome', 'MonthlyRate',
    'NumCompaniesWorked', 'PercentSalaryHike', 'PerformanceRating',
    'RelationshipSatisfaction', 'StockOptionLevel',
    'TotalWorkingYears', 'TrainingTimesLastYear', 'WorkLifeBalance',
    'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion',
    'YearsWithCurrManager'
  ];

  constructor(private fb: FormBuilder, private employeeAttritionService: EmployeeAttritionService) {}

  ngOnInit(): void {
    const formGroupConfig: Record<string, any> = {};
    this.fields.forEach(field => {
      if (this.numericFields.includes(field)) {
        formGroupConfig[field] = ['', [Validators.required, Validators.pattern('^[0-9]+(\.[0-9]+)?$')]]; // Pattern for numbers
      } else {
        formGroupConfig[field] = ['', Validators.required];
      }
    });

    this.inputForm = this.fb.group(formGroupConfig);
    this.groupFieldsForDisplay();
  }

  groupFieldsForDisplay(): void {
    this.fieldGroups = [];
    for (let i = 0; i < this.fields.length; i += 4) {
      this.fieldGroups.push(this.fields.slice(i, i + 4));
    }
  }

  onSubmit(): void {
    if (this.inputForm.invalid) {
      this.inputForm.markAllAsTouched();
      return;
    }

    const formData = this.inputForm.value;
    console.log(this.inputForm.value['EmployeeNumber'])
    this.employeeAttritionService.sendResumeData(formData).subscribe(
      response => { this.responseMessage = response; },
      error => { this.responseMessage = 'An error occurred while submitting the form.'; }
    );
  }
}
