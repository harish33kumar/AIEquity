export interface EmployeeAttrition {
  age: number;
  dailyRate: number;
  department: string; // E.g., 'Sales', 'Research & Development'
  distanceFromHome: number;
  education: number; // Numeric representation of degree levels
  educationField: string;
  employeeNumber: number;
  environmentSatisfaction: number;
  gender: string; // E.g., 'Male', 'Female'
  hourlyRate: number;
  jobInvolvement: number;
  jobLevel: number;
  jobRole: string;
  jobSatisfaction: number;
  monthlyIncome: number;
  monthlyRate: number;
  numCompaniesWorked: number;
  percentSalaryHike: number;
  performanceRating: number;
  relationshipSatisfaction: number;
  stockOptionLevel: number;
  totalWorkingYears: number;
  trainingTimesLastYear: number;
  workLifeBalance: number;
  yearsAtCompany: number;
  yearsInCurrentRole: number;
  yearsSinceLastPromotion: number;
  yearsWithCurrManager: number;
}
