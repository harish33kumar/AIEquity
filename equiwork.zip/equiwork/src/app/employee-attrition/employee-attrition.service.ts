import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EmployeeAttrition } from './employee-attrition.model'; // Import the model

@Injectable({
  providedIn: 'root'
})
export class EmployeeAttritionService {
  private apiUrl = 'http://localhost:5000/predict'; // Replace with your actual API endpoint

  constructor(private http: HttpClient) {}

  sendResumeData(data: EmployeeAttrition): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.apiUrl, data, { headers });
  }
}
